"""Small Portuguese desktop interface; background work never blocks Tk."""
from __future__ import annotations

from pathlib import Path
import queue
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .core import Plan, Result, apply_plan, build_plan, undo_last


class Application:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.plan: Plan | None = None
        self.busy = False
        self.events: queue.Queue = queue.Queue()
        root.title("FolderPilot — Organizador de ficheiros")
        root.geometry("980x670")
        root.minsize(740, 520)
        root.configure(background="#f4f6fa")
        root.protocol("WM_DELETE_WINDOW", self.close)
        style = ttk.Style(root)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("TFrame", background="#f4f6fa")
        style.configure("TLabel", background="#f4f6fa", foreground="#172338", font=("Segoe UI", 10))
        style.configure("Title.TLabel", font=("Segoe UI", 23, "bold"))
        style.configure("TButton", padding=(12, 8), font=("Segoe UI", 10))
        style.configure("Treeview", rowheight=29, font=("Segoe UI", 10))
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), padding=8)
        main = ttk.Frame(root, padding=24)
        main.pack(fill="both", expand=True)
        ttk.Label(main, text="FolderPilot", style="Title.TLabel").pack(anchor="w")
        ttk.Label(main, text="Uma pasta organizada. Tu decides quando.").pack(anchor="w", pady=(0, 18))
        bar = ttk.Frame(main)
        bar.pack(fill="x")
        self.folder = tk.StringVar()
        self.entry = ttk.Entry(bar, textvariable=self.folder, state="readonly")
        self.entry.pack(side="left", fill="x", expand=True, ipady=7)
        self.choose_button = ttk.Button(bar, text="Escolher pasta", command=self.choose)
        self.choose_button.pack(side="left", padx=(10, 0))
        ttk.Label(main, text="Só os ficheiros desta pasta serão analisados. As subpastas ficam como estão.").pack(anchor="w", pady=(9, 14))
        table_frame = ttk.Frame(main)
        table_frame.pack(fill="both", expand=True)
        self.table = ttk.Treeview(table_frame, columns=("source", "target", "size"), show="headings")
        for key, label, width in (("source", "Ficheiro", 280), ("target", "Novo local", 350), ("size", "Tamanho", 110)):
            self.table.heading(key, text=label)
            self.table.column(key, width=width, minwidth=80, anchor="e" if key == "size" else "w")
        scroll = ttk.Scrollbar(table_frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.status = tk.StringVar(value="Escolhe uma pasta, como Transferências, para começar.")
        ttk.Label(main, textvariable=self.status, wraplength=850).pack(anchor="w", pady=(14, 8))
        self.progress = ttk.Progressbar(main, mode="indeterminate")
        self.progress.pack(fill="x", pady=(0, 12))
        buttons = ttk.Frame(main)
        buttons.pack(fill="x")
        self.preview_button = ttk.Button(buttons, text="1. Pré-visualizar", command=self.preview, state="disabled")
        self.preview_button.pack(side="left")
        self.apply_button = ttk.Button(buttons, text="2. Organizar", command=self.apply, state="disabled")
        self.apply_button.pack(side="left", padx=8)
        self.undo_button = ttk.Button(buttons, text="Desfazer última organização", command=self.undo, state="disabled")
        self.undo_button.pack(side="right")
        ttk.Label(main, text="Funciona offline · Sem sobrescrever ficheiros · Histórico guardado na pasta").pack(anchor="w", pady=(16, 0))
        root.after(100, self.poll)

    def set_busy(self, active: bool):
        self.busy = active
        self.choose_button.configure(state="disabled" if active else "normal")
        state = "normal" if not active and self.folder.get() else "disabled"
        self.preview_button.configure(state=state)
        self.undo_button.configure(state=state)
        self.apply_button.configure(state="normal" if not active and self.plan and self.plan.moves else "disabled")
        self.progress.start(12) if active else self.progress.stop()

    def choose(self):
        selected = filedialog.askdirectory(title="Escolhe uma pasta de documentos ou transferências", mustexist=True)
        if selected:
            self.folder.set(selected)
            self.plan = None
            self.table.delete(*self.table.get_children())
            self.status.set("Clica em Pré-visualizar. Nenhum ficheiro será alterado nesta etapa.")
            self.set_busy(False)

    def run(self, job: str, function):
        self.set_busy(True)
        self.status.set("A verificar os ficheiros… Pastas grandes podem demorar.")

        def worker():
            try:
                self.events.put((job, function(), None))
            except Exception as error:
                self.events.put((job, None, str(error)))

        threading.Thread(target=worker, daemon=False).start()

    def preview(self):
        folder = Path(self.folder.get())
        self.plan = None
        self.table.delete(*self.table.get_children())
        self.run("preview", lambda: build_plan(folder))

    def apply(self):
        if not self.plan:
            return
        plan = self.plan
        if messagebox.askyesno("Confirmar organização", f"Mover {len(plan.moves)} ficheiro(s) conforme a pré-visualização?\n\nPoderás desfazer esta operação através do histórico."):
            self.run("apply", lambda: apply_plan(plan))

    def undo(self):
        folder = Path(self.folder.get())
        if messagebox.askyesno("Desfazer", "Restaurar a última organização desta pasta?\n\nFicheiros modificados ou nomes ocupados serão preservados."):
            self.plan = None
            self.run("undo", lambda: undo_last(folder))

    def poll(self):
        try:
            job, result, error = self.events.get_nowait()
        except queue.Empty:
            self.root.after(100, self.poll)
            return
        if error:
            self.plan = None
            self.status.set("Operação interrompida. Consulta o detalhe e volta a pré-visualizar.")
            messagebox.showerror("FolderPilot", error)
        elif job == "preview":
            self.plan = result
            for move in result.moves:
                self.table.insert("", "end", values=(move.source, move.destination, self.human_size(move.size)))
            self.status.set(f"{len(result.moves)} ficheiro(s) a mover · {len(result.skipped)} entrada(s) ignorada(s). Nada foi alterado.")
        else:
            self.plan = None
            self.table.delete(*self.table.get_children())
            action = "movido(s)" if job == "apply" else "restaurado(s)"
            self.status.set(f"{result.changed} ficheiro(s) {action}. {len(result.errors)} problema(s). Pré-visualiza para atualizar a lista.")
            if result.errors:
                messagebox.showwarning("Operação parcial", "\n".join(result.errors[:6]) + ("\nMais detalhes no histórico." if len(result.errors) > 6 else ""))
            elif result.journal is None:
                messagebox.showinfo("FolderPilot", "Não há operações para executar ou desfazer.")
        self.set_busy(False)
        self.root.after(100, self.poll)

    @staticmethod
    def human_size(size: int) -> str:
        value = float(size)
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if value < 1024 or unit == "TB":
                return f"{value:.1f} {unit}"
            value /= 1024
        return str(size)

    def close(self):
        if self.busy:
            messagebox.showinfo("Operação em curso", "Espera que a operação termine antes de fechar.")
        else:
            self.root.destroy()


def main() -> int:
    try:
        root = tk.Tk()
    except tk.TclError as error:
        print(f"Cannot open a desktop window: {error}. Use the CLI on a headless machine.", file=sys.stderr)
        return 1
    Application(root)
    root.mainloop()
    return 0
