"""FolderPilot: preview, organise, undo. No network or third-party dependencies."""

__version__ = "0.1.0"
