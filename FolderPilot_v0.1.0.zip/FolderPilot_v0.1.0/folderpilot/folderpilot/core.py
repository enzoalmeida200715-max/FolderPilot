"""Conservative, non-recursive organisation of a personal data folder.

Moves use an exclusive hard link followed by unlink, so existing destinations
are never replaced. Unsupported filesystems fail without a copy/delete fallback.
This is a local utility, not a security boundary against concurrent local attackers.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
from typing import Iterator
import uuid


CATEGORIES = {
    "Images": {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".heic", ".svg"},
    "Documents": {".pdf", ".txt", ".doc", ".docx", ".odt", ".rtf", ".epub", ".csv", ".xls", ".xlsx", ".ods", ".ppt", ".pptx", ".odp"},
    "Audio": {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".opus"},
    "Videos": {".mp4", ".mkv", ".mov", ".avi", ".webm", ".m4v"},
    "Archives": {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2", ".xz"},
}
EXTENSIONS = {extension: category for category, extensions in CATEGORIES.items() for extension in extensions}
STATE_DIR = ".folderpilot"
PROJECT_MARKERS = {".git", "pyproject.toml", "package.json", "Cargo.toml", "go.mod", "folderpilot"}


class FolderPilotError(Exception):
    """An operation was refused or could not be completed safely."""


@dataclass(frozen=True)
class Move:
    source: str
    destination: str
    size: int
    mtime_ns: int
    sha256: str


@dataclass(frozen=True)
class Plan:
    folder: Path
    moves: tuple[Move, ...]
    skipped: tuple[str, ...]


@dataclass(frozen=True)
class Result:
    journal: Path | None
    changed: int
    errors: tuple[str, ...]


def _is_link(path: Path) -> bool:
    """Also reject Windows junctions and other reparse points."""
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    return stat.S_ISLNK(info.st_mode) or bool(getattr(info, "st_file_attributes", 0) & 0x400)


def _exists(path: Path) -> bool:
    return os.path.lexists(path)


def _root(folder: str | Path) -> Path:
    path = Path(folder).expanduser().absolute()
    if _is_link(path):
        raise FolderPilotError("Choose a real folder, not a link or Windows junction.")
    path = path.resolve(strict=True)
    if not path.is_dir() or path == Path(path.anchor):
        raise FolderPilotError("Choose a personal data folder, not a filesystem root.")
    return path


def _regular(path: Path) -> os.stat_result:
    info = path.lstat()
    if _is_link(path) or not stat.S_ISREG(info.st_mode):
        raise FolderPilotError(f"Not a regular local file: {path.name}")
    return info


def _signature(info: os.stat_result) -> tuple[int, int, int, int]:
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns


def _fingerprint(path: Path) -> tuple[int, int, str]:
    before = _regular(path)
    digest = hashlib.sha256()
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    with os.fdopen(os.open(path, flags), "rb") as stream:
        if _signature(os.fstat(stream.fileno())) != _signature(before):
            raise FolderPilotError(f"File changed while opening: {path.name}")
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
        after = os.fstat(stream.fileno())
    if _signature(before) != _signature(after) or _signature(before) != _signature(_regular(path)):
        raise FolderPilotError(f"File changed while reading: {path.name}")
    return before.st_size, before.st_mtime_ns, digest.hexdigest()


def _component(value: object) -> bool:
    return (isinstance(value, str) and value not in {"", ".", ".."}
            and not any(character in value for character in ("/", "\\", ":", "\0")))


def _paths(root: Path, source: object, destination: object) -> tuple[Path, Path]:
    if not _component(source) or str(source).startswith(".") or not isinstance(destination, str):
        raise FolderPilotError("Invalid source path in plan or history.")
    parts = destination.split("/")
    if len(parts) != 2 or parts[0] not in CATEGORIES or not _component(parts[1]):
        raise FolderPilotError("Invalid destination path in plan or history.")
    original, target = root / str(source), root / parts[0] / parts[1]
    for path in (original, target.parent, target):
        if _is_link(path):
            raise FolderPilotError(f"Links and reparse points are not supported: {path.name}")
    if _exists(target.parent) and not target.parent.is_dir():
        raise FolderPilotError(f"The category is not a directory: {parts[0]}")
    return original, target


def build_plan(folder: str | Path) -> Plan:
    """Read files and hashes without creating, moving or changing anything."""
    root = _root(folder)
    if any(_exists(root / marker) for marker in PROJECT_MARKERS):
        raise FolderPilotError("This looks like a source-code project. Choose a data folder such as Downloads.")
    reserved: dict[str, set[str]] = {}
    for category in CATEGORIES:
        directory = root / category
        if _is_link(directory) or (_exists(directory) and not directory.is_dir()):
            raise FolderPilotError(f"Category is blocked by a file or link: {category}")
        reserved[category] = {path.name.casefold() for path in directory.iterdir()} if directory.exists() else set()
    moves, skipped = [], []
    for source in sorted(root.iterdir(), key=lambda path: (path.name.casefold(), path.name)):
        try:
            info = source.lstat()
            hidden = source.name.startswith(".") or bool(getattr(info, "st_file_attributes", 0) & 0x6)
            category = EXTENSIONS.get(source.suffix.lower())
            if hidden or _is_link(source) or not stat.S_ISREG(info.st_mode) or category is None:
                skipped.append(source.name)
                continue
            if not _component(source.name):
                skipped.append(source.name)
                continue
            name, index = source.name, 2
            while name.casefold() in reserved[category]:
                name = f"{source.stem} ({index}){source.suffix}"
                index += 1
            reserved[category].add(name.casefold())
            size, mtime_ns, digest = _fingerprint(source)
            moves.append(Move(source.name, f"{category}/{name}", size, mtime_ns, digest))
        except (OSError, FolderPilotError) as error:
            skipped.append(f"{source.name}: {error}")
    return Plan(root, tuple(moves), tuple(skipped))


def _state_directory(root: Path) -> Path:
    path = root / STATE_DIR
    if _is_link(path) or (_exists(path) and not path.is_dir()):
        raise FolderPilotError("The history directory is blocked by a file or link.")
    path.mkdir(mode=0o700, exist_ok=True)
    return path


@contextmanager
def _lock(root: Path) -> Iterator[Path]:
    directory = _state_directory(root)
    lock = directory / "operation.lock"
    try:
        descriptor = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError as error:
        raise FolderPilotError("Another operation may be active. See the README for stale-lock recovery.") from error
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            stream.write(str(os.getpid()))
        yield directory
    finally:
        lock.unlink(missing_ok=True)


def _save(path: Path, history: dict) -> None:
    descriptor, name = tempfile.mkstemp(prefix=".history-", suffix=".tmp", dir=path.parent)
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(history, stream, indent=2, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _move_exclusive(source: Path, destination: Path) -> None:
    """An existing destination, including a symlink, causes an error."""
    _regular(source)
    try:
        os.link(source, destination)
    except OSError as error:
        raise FolderPilotError(f"Cannot move {source.name}: {error}. The filesystem must support hard links.") from error
    try:
        source.unlink()
    except OSError:
        # Remove only the new link we just created; preserve the original.
        if _exists(source) and _exists(destination) and os.path.samefile(source, destination):
            destination.unlink()
        raise


def apply_plan(plan: Plan) -> Result:
    root = _root(plan.folder)
    if not plan.moves:
        return Result(None, 0, ())
    with _lock(root) as directory:
        seen = set()
        for move in plan.moves:
            original, target = _paths(root, move.source, move.destination)
            key = move.destination.casefold()
            if key in seen or _exists(target):
                raise FolderPilotError(f"Destination is no longer available: {move.destination}. Preview again.")
            seen.add(key)
            if _fingerprint(original) != (move.size, move.mtime_ns, move.sha256):
                raise FolderPilotError(f"File changed since preview: {move.source}. Preview again.")
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        journal = directory / f"run-{stamp}-{uuid.uuid4().hex[:8]}.json"
        history = {"schema": 1, "root": str(root), "state": "in_progress", "created_at": stamp,
                   "entries": [{**asdict(move), "status": "pending"} for move in plan.moves]}
        _save(journal, history)  # Write-ahead record before any user file moves.
        changed, errors = 0, []
        for entry in history["entries"]:
            try:
                original, target = _paths(root, entry["source"], entry["destination"])
                if _fingerprint(original) != (entry["size"], entry["mtime_ns"], entry["sha256"]):
                    raise FolderPilotError("File changed during the operation.")
                target.parent.mkdir(exist_ok=True)
                _paths(root, entry["source"], entry["destination"])
                _move_exclusive(original, target)
                entry["status"] = "moved"
                changed += 1
            except (OSError, FolderPilotError) as error:
                entry["status"] = "failed"
                entry["error"] = str(error)
                errors.append(f"{entry['source']}: {error}")
            _save(journal, history)
        history["state"] = "complete" if not errors else "partial"
        _save(journal, history)
        return Result(journal, changed, tuple(errors))


def _load_history(path: Path, root: Path) -> dict:
    _regular(path)
    if path.stat().st_size > 32 * 1024 * 1024:
        raise FolderPilotError("History file is too large.")
    try:
        history = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as error:
        raise FolderPilotError("Invalid history JSON.") from error
    if (not isinstance(history, dict) or history.get("schema") != 1
            or history.get("root") != str(root) or not isinstance(history.get("entries"), list)
            or history.get("state") not in {"in_progress", "complete", "partial", "undo_partial", "undone"}):
        raise FolderPilotError("History does not match this folder or format.")
    sources, targets = set(), set()
    for entry in history["entries"]:
        if not isinstance(entry, dict):
            raise FolderPilotError("Invalid history entry.")
        _paths(root, entry.get("source"), entry.get("destination"))
        digest = entry.get("sha256")
        if (not isinstance(digest, str) or len(digest) != 64
                or any(character not in "0123456789abcdef" for character in digest)
                or type(entry.get("size")) is not int or entry["size"] < 0
                or entry.get("status") not in {"pending", "moved", "failed", "restored", "not_moved"}):
            raise FolderPilotError("Invalid history fingerprint or status.")
        if entry["source"] in sources or entry["destination"].casefold() in targets:
            raise FolderPilotError("Duplicate paths in history.")
        sources.add(entry["source"])
        targets.add(entry["destination"].casefold())
    return history


def undo_last(folder: str | Path) -> Result:
    root = _root(folder)
    if not _exists(root / STATE_DIR):
        return Result(None, 0, ())
    with _lock(root) as directory:
        selected = None
        for journal in sorted(directory.glob("run-*.json"), reverse=True):
            history = _load_history(journal, root)
            if history["state"] != "undone":
                selected = journal, history
                break
        if selected is None:
            return Result(None, 0, ())
        journal, history = selected
        changed, errors = 0, []
        for entry in reversed(history["entries"]):
            if entry["status"] in {"restored", "not_moved"}:
                continue
            try:
                original, target = _paths(root, entry["source"], entry["destination"])
                if _exists(original) and not _exists(target):
                    entry["status"] = "not_moved"
                else:
                    if not _exists(target):
                        raise FolderPilotError("Both recorded paths are missing; restore manually from a backup.")
                    size, _, digest = _fingerprint(target)
                    if (size, digest) != (entry["size"], entry["sha256"]):
                        raise FolderPilotError("The organised file has changed; leaving it untouched.")
                    if _exists(original):
                        if not os.path.samefile(original, target):
                            raise FolderPilotError("The original name is occupied; leaving both files untouched.")
                        # Recover an interruption between creating the link and removing the original.
                        target.unlink()
                    else:
                        _move_exclusive(target, original)
                    entry["status"] = "restored"
                    changed += 1
            except (OSError, FolderPilotError) as error:
                errors.append(f"{entry['source']}: {error}")
            _save(journal, history)
        history["state"] = "undo_partial" if errors else "undone"
        _save(journal, history)
        return Result(journal, changed, tuple(errors))
