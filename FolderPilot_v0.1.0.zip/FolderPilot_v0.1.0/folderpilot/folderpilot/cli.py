"""Command line: preview by default; mutations need an explicit flag."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from dataclasses import asdict

from . import __version__
from .core import FolderPilotError, apply_plan, build_plan, undo_last


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="FolderPilot: preview, organise and undo local file moves.")
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)
    preview = commands.add_parser("preview", help="Read-only preview")
    preview.add_argument("folder", type=Path)
    preview.add_argument("--json", action="store_true", help="Print the plan as JSON")
    organize = commands.add_parser("organize", help="Preview; add --apply to actually move files")
    organize.add_argument("folder", type=Path)
    organize.add_argument("--apply", action="store_true")
    undo = commands.add_parser("undo", help="Restore the last unfinished or completed batch")
    undo.add_argument("folder", type=Path)
    undo.add_argument("--yes", action="store_true", help="Confirm restoring files")
    commands.add_parser("gui", help="Open the desktop interface (Portuguese)")
    args = parser.parse_args(argv)
    try:
        if args.command == "gui":
            from .gui import main as gui_main
            return gui_main()
        if args.command == "undo":
            if not args.yes:
                print("No changes made. Add --yes to undo the most recent batch.")
                return 0
            result = undo_last(args.folder)
            print(f"Restored: {result.changed}")
        else:
            plan = build_plan(args.folder)
            if getattr(args, "json", False):
                print(json.dumps({"folder": str(plan.folder), "moves": [asdict(move) for move in plan.moves],
                                  "skipped": plan.skipped}, indent=2, ensure_ascii=False))
                return 0
            for move in plan.moves:
                print(f"{move.source!r} -> {move.destination!r} ({move.size:,} bytes)")
            print(f"Planned: {len(plan.moves)} | Skipped: {len(plan.skipped)}")
            if args.command == "preview" or not args.apply:
                print("Preview only. No files were changed.")
                return 0
            result = apply_plan(plan)
            print(f"Moved: {result.changed}")
        if result.journal:
            print(f"History: {result.journal}")
        for error in result.errors:
            print(error, file=sys.stderr)
        return 1 if result.errors else 0
    except (FolderPilotError, OSError) as error:
        print(f"FolderPilot: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
