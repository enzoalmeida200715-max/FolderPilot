from dataclasses import replace
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from folderpilot.core import FolderPilotError, Plan, apply_plan, build_plan, undo_last


class OrganizerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)

    def write(self, name, content=b"sample"):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
        return path

    def organize(self, name="report.pdf", content=b"report"):
        self.write(name, content)
        return apply_plan(build_plan(self.root))

    def edit_history(self, journal, change):
        history = json.loads(journal.read_text(encoding="utf-8"))
        change(history)
        journal.write_text(json.dumps(history), encoding="utf-8")

    def test_preview_does_not_change_files_or_create_state(self):
        self.write("invoice.pdf", b"invoice")
        plan = build_plan(self.root)
        self.assertEqual(len(plan.moves), 1)
        self.assertEqual(plan.moves[0].destination, "Documents/invoice.pdf")
        self.assertEqual(sorted(path.name for path in self.root.iterdir()), ["invoice.pdf"])

    def test_round_trip_preserves_bytes_and_modification_time(self):
        file = self.write("férias.PNG", b"image bytes\x00\xff")
        timestamp = file.stat().st_mtime_ns
        result = apply_plan(build_plan(self.root))
        self.assertEqual(result.changed, 1)
        self.assertFalse(file.exists())
        restored = undo_last(self.root)
        self.assertEqual(restored.changed, 1)
        self.assertFalse(restored.errors)
        self.assertEqual(file.read_bytes(), b"image bytes\x00\xff")
        self.assertEqual(file.stat().st_mtime_ns, timestamp)

    def test_existing_file_is_preserved_and_new_file_gets_suffix(self):
        self.write("Documents/a.pdf", b"existing")
        self.write("a.pdf", b"new")
        result = apply_plan(build_plan(self.root))
        self.assertEqual(result.changed, 1)
        self.assertEqual((self.root / "Documents/a.pdf").read_bytes(), b"existing")
        self.assertEqual((self.root / "Documents/a (2).pdf").read_bytes(), b"new")

    def test_name_reservation_is_case_insensitive(self):
        self.write("Documents/A.PDF")
        self.write("a.pdf")
        self.assertEqual(build_plan(self.root).moves[0].destination, "Documents/a (2).pdf")

    def test_subdirectories_hidden_unknown_and_partial_files_are_ignored(self):
        for name in ("nested/report.pdf", ".secret.txt", "program.exe", "script.py", "a.pdf.crdownload"):
            self.write(name)
        self.assertEqual(build_plan(self.root).moves, ())
        self.assertFalse((self.root / ".folderpilot").exists())

    def test_project_folder_is_refused(self):
        self.write("pyproject.toml")
        self.write("a.pdf")
        with self.assertRaises(FolderPilotError):
            build_plan(self.root)

    def test_new_destination_after_preview_refuses_whole_batch(self):
        self.write("a.pdf")
        self.write("b.pdf")
        plan = build_plan(self.root)
        self.write("Documents/b.pdf", b"keep")
        with self.assertRaises(FolderPilotError):
            apply_plan(plan)
        self.assertTrue((self.root / "a.pdf").exists())
        self.assertTrue((self.root / "b.pdf").exists())
        self.assertEqual((self.root / "Documents/b.pdf").read_bytes(), b"keep")

    def test_file_modified_after_preview_is_preserved(self):
        file = self.write("a.pdf", b"old")
        plan = build_plan(self.root)
        file.write_bytes(b"new")
        with self.assertRaises(FolderPilotError):
            apply_plan(plan)
        self.assertEqual(file.read_bytes(), b"new")

    def test_hash_detects_same_size_change_even_with_same_timestamp(self):
        file = self.write("a.pdf", b"abc")
        plan = build_plan(self.root)
        timestamp = file.stat().st_mtime_ns
        file.write_bytes(b"xyz")
        os.utime(file, ns=(timestamp, timestamp))
        with self.assertRaises(FolderPilotError):
            apply_plan(plan)

    def test_undo_preserves_modified_destination(self):
        self.organize()
        target = self.root / "Documents/report.pdf"
        target.write_bytes(b"edited")
        result = undo_last(self.root)
        self.assertEqual(result.changed, 0)
        self.assertTrue(result.errors)
        self.assertEqual(target.read_bytes(), b"edited")

    def test_undo_never_overwrites_an_occupied_original_name(self):
        self.organize()
        self.write("report.pdf", b"another file")
        result = undo_last(self.root)
        self.assertTrue(result.errors)
        self.assertEqual((self.root / "report.pdf").read_bytes(), b"another file")
        self.assertEqual((self.root / "Documents/report.pdf").read_bytes(), b"report")

    def test_undo_conflict_can_be_resolved_and_retried(self):
        self.organize()
        blocker = self.write("report.pdf", b"another file")
        self.assertTrue(undo_last(self.root).errors)
        blocker.rename(self.root / "my-other-report.pdf")
        self.assertEqual(undo_last(self.root).changed, 1)

    def test_undo_is_idempotent(self):
        self.organize()
        self.assertEqual(undo_last(self.root).changed, 1)
        self.assertEqual(undo_last(self.root).changed, 0)

    def test_multiple_batches_undo_in_reverse_order(self):
        self.organize("one.pdf", b"1")
        self.organize("two.pdf", b"2")
        undo_last(self.root)
        self.assertTrue((self.root / "two.pdf").exists())
        self.assertFalse((self.root / "one.pdf").exists())
        undo_last(self.root)
        self.assertTrue((self.root / "one.pdf").exists())

    def test_undo_without_history_is_read_only(self):
        self.assertIsNone(undo_last(self.root).journal)
        self.assertEqual(list(self.root.iterdir()), [])

    def test_unsupported_hard_links_leave_original_untouched(self):
        file = self.write("a.pdf", b"keep")
        plan = build_plan(self.root)
        with patch("folderpilot.core.os.link", side_effect=OSError("not supported")):
            result = apply_plan(plan)
        self.assertEqual(result.changed, 0)
        self.assertTrue(result.errors)
        self.assertEqual(file.read_bytes(), b"keep")

    def test_interruption_after_link_before_unlink_can_be_undone(self):
        result = self.organize()
        original, target = self.root / "report.pdf", self.root / "Documents/report.pdf"
        os.link(target, original)
        self.edit_history(result.journal, lambda data: data.update(state="in_progress"))
        self.assertEqual(undo_last(self.root).changed, 1)
        self.assertTrue(original.exists())
        self.assertFalse(target.exists())

    def test_pending_entry_after_move_can_be_undone(self):
        result = self.organize()
        def change(data):
            data["state"] = "in_progress"
            data["entries"][0]["status"] = "pending"
        self.edit_history(result.journal, change)
        self.assertEqual(undo_last(self.root).changed, 1)

    def test_failed_history_write_prevents_first_move(self):
        file = self.write("a.pdf")
        plan = build_plan(self.root)
        with patch("folderpilot.core._save", side_effect=OSError("disk full")):
            with self.assertRaises(OSError):
                apply_plan(plan)
        self.assertTrue(file.exists())
        self.assertFalse((self.root / "Documents/a.pdf").exists())

    def test_missing_source_after_preview_does_not_move_other_files(self):
        self.write("a.pdf")
        missing = self.write("b.pdf")
        plan = build_plan(self.root)
        missing.unlink()
        with self.assertRaises(OSError):
            apply_plan(plan)
        self.assertTrue((self.root / "a.pdf").exists())

    def test_history_path_traversal_is_refused(self):
        result = self.organize()
        self.edit_history(result.journal, lambda data: data["entries"][0].update(source="../outside.pdf"))
        with self.assertRaises(FolderPilotError):
            undo_last(self.root)
        self.assertTrue((self.root / "Documents/report.pdf").exists())

    def test_history_mismatched_root_is_refused(self):
        result = self.organize()
        self.edit_history(result.journal, lambda data: data.update(root="/not-this-folder"))
        with self.assertRaises(FolderPilotError):
            undo_last(self.root)

    def test_corrupt_history_is_refused(self):
        result = self.organize()
        result.journal.write_text("broken JSON", encoding="utf-8")
        with self.assertRaises(FolderPilotError):
            undo_last(self.root)

    def test_active_lock_prevents_changes(self):
        self.write("a.pdf")
        self.write(".folderpilot/operation.lock", b"123")
        with self.assertRaises(FolderPilotError):
            apply_plan(build_plan(self.root))
        self.assertTrue((self.root / "a.pdf").exists())

    def test_zero_byte_files_work(self):
        result = self.organize("empty.txt", b"")
        self.assertEqual(result.changed, 1)
        self.assertEqual(undo_last(self.root).changed, 1)
        self.assertEqual((self.root / "empty.txt").read_bytes(), b"")

    def test_category_blocked_by_file_is_refused(self):
        self.write("Documents")
        self.write("a.pdf")
        with self.assertRaises(FolderPilotError):
            build_plan(self.root)

    def symlink_or_skip(self, source, target, directory=False):
        try:
            target.symlink_to(source, target_is_directory=directory)
        except (OSError, NotImplementedError):
            self.skipTest("Creating symlinks is not permitted on this host")

    def test_symlink_file_is_ignored(self):
        original = self.write("original.bin")
        self.symlink_or_skip(original, self.root / "link.pdf")
        self.assertFalse(build_plan(self.root).moves)

    def test_symlink_category_is_refused(self):
        outside = self.root / "elsewhere"
        outside.mkdir()
        self.symlink_or_skip(outside, self.root / "Documents", directory=True)
        self.write("a.pdf")
        with self.assertRaises(FolderPilotError):
            build_plan(self.root)

    def test_symlink_history_directory_is_refused(self):
        outside = self.root / "elsewhere"
        outside.mkdir()
        self.symlink_or_skip(outside, self.root / ".folderpilot", directory=True)
        self.write("a.pdf")
        with self.assertRaises(FolderPilotError):
            apply_plan(build_plan(self.root))

    def test_cli_organize_without_apply_is_read_only(self):
        self.write("a.pdf")
        result = subprocess.run([sys.executable, "-m", "folderpilot", "organize", str(self.root)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("Preview only", result.stdout)
        self.assertTrue((self.root / "a.pdf").exists())
        self.assertFalse((self.root / ".folderpilot").exists())

    def test_cli_preview_json(self):
        self.write("a.pdf")
        result = subprocess.run([sys.executable, "-m", "folderpilot", "preview", str(self.root), "--json"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["moves"][0]["source"], "a.pdf")

    def test_cli_undo_without_confirmation_does_not_mutate(self):
        self.organize()
        result = subprocess.run([sys.executable, "-m", "folderpilot", "undo", str(self.root)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0)
        self.assertFalse((self.root / "report.pdf").exists())


if __name__ == "__main__":
    unittest.main()
