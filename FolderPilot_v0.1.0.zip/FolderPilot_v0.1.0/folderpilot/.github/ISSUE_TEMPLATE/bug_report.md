---
name: Bug report
about: Report a reproducible problem
title: ''
labels: bug
assignees: ''
---

## What happened?

## What did you expect?

## Steps to reproduce with disposable example files

## Environment

- Operating system:
- Python version:
- FolderPilot version:
- Local disk or other storage:

## Error message

Remove personal paths, credentials and private content before posting.
